import React from "react";

export default function Sobre() {
  return (
    <div className="p-6">
      <h1 className="text-3xl font-bold mb-4">Sobre Nós</h1>
      <p>
        Somos uma empresa dedicada a fornecer soluções de qualidade para nossos
        clientes. Nossa equipe é formada por profissionais experientes e
        comprometidos com o sucesso dos nossos projetos.
      </p>
    </div>
  );
}
