import { PageTitle } from "@/components/ui/PageTitle";

const Services = () => (
  <div className="max-w-4xl mx-auto p-6">
    <PageTitle title="Serviços" />
    <ul className="list-disc ml-5 text-gray-700 space-y-2">
      <li>Desenvolvimento Web sob medida</li>
      <li>Consultoria em TI</li>
      <li>Hospedagem e manutenção de sistemas</li>
      <li>Integração com APIs e automações</li>
    </ul>
  </div>
);

export default Services;
