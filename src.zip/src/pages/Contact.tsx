import { ContactForm } from "@/components/ui/ContactForm";
import { PageTitle } from "@/components/ui/PageTitle";

const Contact = () => {
  return (
    <div className="max-w-2xl mx-auto p-6">
      <PageTitle title="Contato" />
      <p className="mb-4 text-gray-600">
        Fale conosco preenchendo o formulário abaixo:
      </p>
      <ContactForm />
    </div>
  );
};

export default Contact;
