import React from "react";

interface FormProps extends React.FormHTMLAttributes<HTMLFormElement> {
  children: React.ReactNode;
  className?: string;
}

export const Form = ({ children, className = "", ...props }: FormProps) => (
  <form className={`space-y-4 ${className}`} {...props}>
    {children}
  </form>
);
