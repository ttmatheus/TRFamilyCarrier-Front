import { Form } from "./Form";
import { Input } from "./Input";
import { Button } from "./Button";

export const ContactForm = () => {
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert("Mensagem enviada com sucesso!");
  };

  return (
    <Form onSubmit={handleSubmit}>
      <Input label="Nome" name="name" required />
      <Input label="Email" name="email" type="email" required />
      <div className="flex flex-col gap-1">
        <label className="text-sm font-medium text-gray-700">Mensagem</label>
        <textarea
          name="message"
          required
          className="px-3 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
      </div>
      <Button type="submit">Enviar</Button>
    </Form>
  );
};
