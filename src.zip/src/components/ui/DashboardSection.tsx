interface DashboardSectionProps {
  title: string;
  children: React.ReactNode;
}

export const DashboardSection = ({
  title,
  children,
}: DashboardSectionProps) => (
  <section className="bg-white p-6 rounded-xl shadow-md mb-6">
    <h2 className="text-xl font-semibold mb-4">{title}</h2>
    {children}
  </section>
);
